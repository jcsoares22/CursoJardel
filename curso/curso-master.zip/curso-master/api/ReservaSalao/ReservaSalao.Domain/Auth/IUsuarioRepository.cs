﻿using ReservaSalao.Domain.Shared;

namespace ReservaSalao.Domain.Auth;

public interface IUsuarioRepository : IRepository<UsuarioEntity>
{
}
