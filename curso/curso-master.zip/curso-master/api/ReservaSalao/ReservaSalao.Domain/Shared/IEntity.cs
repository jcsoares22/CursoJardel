﻿namespace ReservaSalao.Domain.Shared;

public interface IEntity
{
    public int Id { get; set; }
}
