﻿namespace ReservaSalao.Application.Shared;

public class AppSettings
{
    public required string Secret { get; set; }
}
